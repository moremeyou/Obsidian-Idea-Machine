
## 📬 Inbox
```tag-summary
tags: #anecdote #dote #lesson 
sections: Anecdotes, Lessons
```

## Anecdotes
- First item
## Lessons
- First item
